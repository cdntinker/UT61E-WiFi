Stolen from https://github.com/esp8266/Arduino/tree/master/libraries/LittleFS

For some weird reason, trying to access this as part of the actual core library fails to find LittleFS.h

NFC why, but this is the case.
